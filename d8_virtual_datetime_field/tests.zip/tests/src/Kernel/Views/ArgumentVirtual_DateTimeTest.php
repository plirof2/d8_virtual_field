<?php

namespace Drupal\Tests\virtual_datetime\Kernel\Views;

use Drupal\node\Entity\Node;
use Drupal\views\Views;

/**
 * Tests the Drupal\virtual_datetime\Plugin\views\filter\Date handler.
 *
 * @group virtual_datetime
 */
class ArgumentVirtual_DateTimeTest extends Virtual_DateTimeHandlerTestBase {

  /**
   * {@inheritdoc}
   */
  public static $testViews = ['test_argument_virtual_datetime'];

  /**
   * {@inheritdoc}
   */
  protected function setUp($import_test_views = TRUE) {
    parent::setUp($import_test_views);

    // Add some basic test nodes.
    $dates = [
      '2000-10-10',
      '2001-10-10',
      '2002-01-01',
    ];
    foreach ($dates as $date) {
      $node = Node::create([
        'title' => $this->randomMachineName(8),
        'type' => 'page',
        'field_date' => [
          'value' => $date,
        ]
      ]);
      $node->save();
      $this->nodes[] = $node;
    }
  }

  /**
   * Test year argument.
   *
   * @see \Drupal\virtual_datetime\Plugin\views\argument\YearDate
   */
  public function testVirtual_DatetimeArgumentYear() {
    $view = Views::getView('test_argument_virtual_datetime');

    // The 'default' display has the 'year' argument.
    $view->setDisplay('default');
    $this->executeView($view, ['2000']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[0]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();

    $view->setDisplay('default');
    $this->executeView($view, ['2002']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[2]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();
  }

  /**
   * Test month argument.
   *
   * @see \Drupal\virtual_datetime\Plugin\views\argument\MonthDate
   */
  public function testVirtual_DatetimeArgumentMonth() {
    $view = Views::getView('test_argument_virtual_datetime');
    // The 'embed_1' display has the 'month' argument.
    $view->setDisplay('embed_1');

    $this->executeView($view, ['10']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[0]->id()];
    $expected[] = ['nid' => $this->nodes[1]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();

    $view->setDisplay('embed_1');
    $this->executeView($view, ['01']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[2]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();
  }

  /**
   * Test day argument.
   *
   * @see \Drupal\virtual_datetime\Plugin\views\argument\DayDate
   */
  public function testVirtual_DatetimeArgumentDay() {
    $view = Views::getView('test_argument_virtual_datetime');

    // The 'embed_2' display has the 'day' argument.
    $view->setDisplay('embed_2');
    $this->executeView($view, ['10']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[0]->id()];
    $expected[] = ['nid' => $this->nodes[1]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();

    $view->setDisplay('embed_2');
    $this->executeView($view, ['01']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[2]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();
  }

  /**
   * Test year, month, and day arguments combined.
   */
  public function testVirtual_DatetimeArgumentAll() {
    $view = Views::getView('test_argument_virtual_datetime');
    // The 'embed_3' display has year, month, and day arguments.
    $view->setDisplay('embed_3');

    $this->executeView($view, ['2000', '10', '10']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[0]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();

    $view->setDisplay('embed_3');
    $this->executeView($view, ['2002', '01', '01']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[2]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();
  }

  /**
   * Test week WW argument.
   */
  public function testVirtual_DatetimeArgumentWeek() {
    $view = Views::getView('test_argument_virtual_datetime');
    // The 'embed_4' display has WW argument.
    $view->setDisplay('embed_4');

    $this->executeView($view, ['41']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[0]->id()];
    $expected[] = ['nid' => $this->nodes[1]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();

    $view->setDisplay('embed_4');
    $this->executeView($view, ['01']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[2]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();
  }

  /**
   * Test full_date CCYYMMDD argument.
   */
  public function testVirtual_DatetimeArgumentFullDate() {
    $view = Views::getView('test_argument_virtual_datetime');
    // The 'embed_5' display has CCYYMMDD argument.
    $view->setDisplay('embed_5');

    $this->executeView($view, ['20001010']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[0]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();

    $view->setDisplay('embed_5');
    $this->executeView($view, ['20020101']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[2]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();
  }

  /**
   * Test year_month CCYYMM argument.
   */
  public function testVirtual_DatetimeArgumentYearMonth() {
    $view = Views::getView('test_argument_virtual_datetime');
    // The 'embed_6' display has CCYYMM argument.
    $view->setDisplay('embed_6');

    $this->executeView($view, ['200010']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[0]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();

    $view->setDisplay('embed_6');
    $this->executeView($view, ['200201']);
    $expected = [];
    $expected[] = ['nid' => $this->nodes[2]->id()];
    $this->assertIdenticalResultset($view, $expected, $this->map);
    $view->destroy();
  }

}
